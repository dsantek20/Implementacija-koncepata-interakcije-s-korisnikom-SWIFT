//
//  Local_notification_jednostavnaApp.swift
//  Local notification-jednostavna
//
//  Created by Santek on 30.10.2022..
//

import SwiftUI

@main
struct Local_notification_jednostavnaApp: App {
    
    
    init(){
        let center=UNUserNotificationCenter.current()
        
        center.requestAuthorization(options:[.alert,.sound,.badge]){result,error in
            if let error=error{
                print(error)
            }
            
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
