//
//  ContentView.swift
//  Local notification-jednostavna
//
//  Created by Santek on 30.10.2022..
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Button("Prikaži notifikaciju"){
                let center=UNUserNotificationCenter.current()
                
                let content=UNMutableNotificationContent()
                content.title="Poruka"
                content.body="Ovo je poruka od aplikacije"
                
                
                let trigger=UNTimeIntervalNotificationTrigger(timeInterval: 8.0, repeats:true)
                
                let request=UNNotificationRequest(identifier: "Identifier", content: content, trigger: trigger)
            
                center.add(request){error in
                    if let error=error{
                        print(error)
                    }
                    
                }
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
