//
//  ContentView.swift
//  Alert s tekstualnim unosom
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI

struct ContentView: View {
    @State private var presentAlert = false
    @State private var username: String = ""
    @State private var password: String = ""
    
    var body: some View {
        Button("Prijavi se") {
            presentAlert = true
        }
        .alert("Prijava", isPresented: $presentAlert, actions: {
            TextField("Korisničko ime", text: $username)

            SecureField("Lozinka", text: $password)

            
            Button("Login", action: {})
            Button("Cancel", role: .cancel, action: {})
        }, message: {
            Text("Unesite korisničko ime i lozinku.")
        })
    }
}
