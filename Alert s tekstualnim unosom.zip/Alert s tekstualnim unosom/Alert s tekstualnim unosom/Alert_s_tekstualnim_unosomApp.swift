//
//  Alert_s_tekstualnim_unosomApp.swift
//  Alert s tekstualnim unosom
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI

@main
struct Alert_s_tekstualnim_unosomApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
