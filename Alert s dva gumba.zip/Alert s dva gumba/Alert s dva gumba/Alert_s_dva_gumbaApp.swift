//
//  Alert_s_dva_gumbaApp.swift
//  Alert s dva gumba
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI

@main
struct Alert_s_dva_gumbaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
