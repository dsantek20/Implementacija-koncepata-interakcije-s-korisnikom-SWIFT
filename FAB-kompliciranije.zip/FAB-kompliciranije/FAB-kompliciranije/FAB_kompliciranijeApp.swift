//
//  FAB_kompliciranijeApp.swift
//  FAB-kompliciranije
//
//  Created by Santek on 31.10.2022..
//

import SwiftUI

@main
struct FAB_kompliciranijeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
