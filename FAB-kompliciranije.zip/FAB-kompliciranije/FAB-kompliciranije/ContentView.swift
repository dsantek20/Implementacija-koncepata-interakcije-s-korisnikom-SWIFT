//
//  ContentView.swift
//  FAB-kompliciranije
//
//  Created by Santek on 31.10.2022..
//

import SwiftUI

struct ContentView: View {
    @State var show = false
    var body: some View {
        ZStack{
            VStack{
                Spacer()
                HStack{
                    Spacer()
                    Expandable(show: $show)
                }.padding([.bottom,.trailing],30)
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    
    static var previews: some View {
        ContentView()
    }
}

struct Expandable: View{
    @Binding var show : Bool
    var body : some View{
        VStack{
            
            if self.show{
                Button(action: {
                    self.show.toggle()
                }){
                    Image(systemName:"plus").resizable().frame(width: 15,height: 15).padding(22)
                        
                }
                .background(Color.green)
                .foregroundColor(.white)
                .clipShape(Circle())
                
                Button(action: {
                    self.show.toggle()
                }){
                    Image(systemName:"minus").resizable().frame(width: 15,height: 15).padding(22)
                        
                }
                .background(Color.green)
                .foregroundColor(.white)
                .clipShape(Circle())
            }
            
            Button(action: {
                self.show.toggle()
            }){
                Image(systemName:"chevron.up").resizable().frame(width: 25,height: 15).padding(22)
                    
            }
            .background(Color.green)
            .foregroundColor(.white)
            .clipShape(Circle())
            .rotationEffect(.init(degrees: self.show ? 180 : 0))
        }.animation(.spring())
    }
}
