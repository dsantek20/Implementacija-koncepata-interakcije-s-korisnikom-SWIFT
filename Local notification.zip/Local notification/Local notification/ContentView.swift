//
//  ContentView.swift
//  Local notification
//
//  Created by Santek on 30.10.2022..
//

import SwiftUI

enum NotificationAction: String{
    case dimiss
    case reminder
}

enum NotificationCategory: String{
    case  general
}



struct ContentView: View {
    var body: some View {
        VStack {
            Button("Prikaži notifikaciju"){
                let center=UNUserNotificationCenter.current()
                
                let content=UNMutableNotificationContent()
                content.title="Poruka"
                content.body="Ovo je poruka od aplikacije"
                content.categoryIdentifier=NotificationCategory.general.rawValue
                
                
                if let url=Bundle.main.url(forResource:"download", withExtension:"jpeg"){
                    if let attachment=try? UNNotificationAttachment(identifier: "image", url: url,options:nil){
                        content.attachments=[attachment]
                    }
                }
                
                let trigger=UNTimeIntervalNotificationTrigger(timeInterval: 5.0, repeats:false)
                
                let request=UNNotificationRequest(identifier: "Identifier", content: content, trigger: trigger)
                
                let dismiss=UNNotificationAction(identifier:NotificationAction.dimiss.rawValue, title:"Dismiss",options: [])
                
                let reminder=UNNotificationAction(identifier:NotificationAction.reminder.rawValue, title:"Reminder",options: [])
                
                let generalCategory=UNNotificationCategory(identifier: NotificationCategory.general.rawValue, actions: [dismiss,reminder], intentIdentifiers: [], options: [])
                
                center.setNotificationCategories([generalCategory])
                
                center.add(request){error in
                    if let error=error{
                        print(error)
                    }
                    
                }
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
