//
//  Obican_AlertApp.swift
//  Obican Alert
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI

@main
struct Obican_AlertApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
