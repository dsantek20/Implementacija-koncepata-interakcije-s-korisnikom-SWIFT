//
//  ContentView.swift
//  Obican Alert
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI

struct ContentView: View {
    @State private var showingAlert = false

    var body: some View {
        Button("Pokaži poruku") {
            showingAlert = true
        }
        .alert("Neka poruka", isPresented: $showingAlert) {
            
        }
    }
}
