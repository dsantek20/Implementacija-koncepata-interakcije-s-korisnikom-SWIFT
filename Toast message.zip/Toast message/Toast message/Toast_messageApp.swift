//
//  Toast_messageApp.swift
//  Toast message
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI

@main
struct Toast_messageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
