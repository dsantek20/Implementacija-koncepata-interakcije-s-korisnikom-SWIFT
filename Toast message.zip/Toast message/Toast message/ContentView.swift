//
//  ContentView.swift
//  Toast message
//
//  Created by Santek on 29.10.2022..
//

import SwiftUI
import SimpleToast


struct ContentView: View {
    @State private var showToast=false;
   
    private var toastOptions=SimpleToastOptions(
        alignment: .bottom,
        hideAfter: 2,
        animation: .default,
        modifierType: .slide
        
    )
    var body: some View {
        VStack {
            Button("Pokaži poruku"){
                showToast.toggle()
            }
            
        }
        .simpleToast(isPresented: $showToast, options: toastOptions, onDismiss: {
            
        }){
            HStack{
                Image(systemName: "heart.fill")
                Text("Ovo je ikona srca").bold()
            }
            .padding(55)
            .background(Color.red.opacity(1.0))
            .foregroundColor(Color.white)
            .cornerRadius(166666)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
