//
//  FABApp.swift
//  FAB
//
//  Created by Santek on 31.10.2022..
//

import SwiftUI

@main
struct FABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
