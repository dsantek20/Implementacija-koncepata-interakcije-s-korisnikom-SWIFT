//
//  ContentView.swift
//  FAB
//
//  Created by Santek on 31.10.2022..
//

import SwiftUI

struct ContentView: View {
    @State private var text="Prije nego smo pritisnuli gumb"
    var body: some View {
        ZStack {
            Text(text)
            VStack{
                Spacer()
                HStack{
                    Spacer()
                    Button(action:{
                        self.text="Nakon što smo pritisnuli gumb"
                        
                    }, label:{
                        Image(systemName:"plus")
                            .font(.largeTitle)
                            .frame(width: 70,height: 70)
                            .background(Color.blue.opacity(0.5))
                            .clipShape(Circle())
                            .foregroundColor(.white)
                    })
                    .padding()
                    .shadow(radius: 2)
                }
            }
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
